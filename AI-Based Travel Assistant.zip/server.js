const express = require('express');
const mysql = require('mysql');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'your_mysql_user',
  password: 'your_password',
  database: 'travel_assistant'
});

db.connect(err => {
  if (err) throw err;
  console.log('✅ MySQL connected');
});

app.post('/log', (req, res) => {
  const { from, to, date, city, action } = req.body;
  const sql = 'INSERT INTO travel_logs (`from`, `to`, travel_date, city, action) VALUES (?, ?, ?, ?, ?)';
  db.query(sql, [from, to, date, city, action], (err, result) => {
    if (err) {
      console.error(err);
      return res.status(500).send('❌ Database error');
    }
    res.send('✅ Logged to SQL');
  });
});

app.listen(3000, () => console.log('🚀 Server running on http://localhost:3000'));
